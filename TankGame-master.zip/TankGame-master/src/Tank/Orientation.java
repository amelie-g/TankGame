
package Tank;

public class Orientation {
   public enum Direction {
    Up, Down, Left, Right
    }
}

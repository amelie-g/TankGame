# TankGame-Team06
Amelie Cameron

Please see Documentation.pdf for details and how to run game

# TankGame
2 player game 

Tank 1 controls wasd Tank 2 controls arrow keypad

Each tank can shoot to damage other tank, barriers, etc.
